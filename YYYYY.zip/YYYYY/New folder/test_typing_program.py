import unittest
import typing_program

class test_typing_program(unittest.TestCase):

    def test_Spacebar(self):
        pass

    def test_backspace(self):
        pass

    def test_check(self):
        pass

    def test_instantaniousCheck(self):
        pass

    def test_keyBinding(self):
        pass

    def test_doStatistics(self):
        pass

    def test_refresh(self):
        pass

    def test_show(self):
        pass

    def test_startupFrameButton(self):
        pass